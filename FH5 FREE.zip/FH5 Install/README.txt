How to play Forza Horizon 5:

1. Extract zip file.
2. Open folder named FH5 Install.
3. Right click on Forza Horizon 5 (with the tree icon), then run as administrator.
4. Enjoy!
